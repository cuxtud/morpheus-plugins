//# sourceMappingURL=instance-tab.js.map
var process=process||{env:{NODE_ENV:"development"}};console.log("Script loaded from AssetPipeline");