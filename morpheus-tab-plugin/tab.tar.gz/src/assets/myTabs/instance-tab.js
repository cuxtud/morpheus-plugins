console.log("Script loaded from AssetPipeline");
